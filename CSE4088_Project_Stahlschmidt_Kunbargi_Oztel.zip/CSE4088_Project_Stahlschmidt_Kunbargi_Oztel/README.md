# CSE4088 Machine Learning Project 

Team Members:

Yunus Ahmed Stahlschmidt	150119814

Sameeh N O Kunbargi	150119693

Muhammed Fatih Öztel	150119907

---

Make sure you have installed required python libraries.

- numpy
- sklearn
- seaborn
- keras
- pandas
- matplotlib

---

To generate NN model visualization, please install Graphviz from https://graphviz.org/

---

1) To run the code, open the breast_cancer.ipynb file
2) Run each cell in the given order